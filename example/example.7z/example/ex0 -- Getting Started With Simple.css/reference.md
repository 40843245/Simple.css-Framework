# reference
## guide reference
See [`Getting Started With Simple.css`](https://github.com/kevquirk/simple.css/wiki/Getting-Started-With-Simple.css)
